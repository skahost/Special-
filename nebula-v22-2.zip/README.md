#                    dP                dP          
#                    88                88          
#  88d888b. .d8888b. 88d888b. dP    dP 88 .d8888b. 
#  88'  `88 88ooood8 88'  '88 88    88 88 88'  '88 
#  88    88 88.  ... 88.  .88 88.  .88 88 88.  .88 
#  dP    dP `88888P' 88Y8888' '88888P' dP '88888P8  v2.1


* Welcome to Nebula!
You just got your hands on the #1 sold and reviewed theme for Pterodactyl :)! I hope you like the silly little theme I made!
-> Got feedback? Let me know! https://github.com/prplwtf/nebula/issues/new


* Extension installation.
Before you can start using Nebula, you'll need Blueprint. Blueprint allows themes like Nebula to have great compatibility with other modifications made by extensions. You can find more information, download links and documentation at **https://blueprint.zip**.

After you've installed Blueprint, drag and drop the `nebula.blueprint` file over to your Pterodactyl folder (commonly /var/www/pterodactyl) and run `blueprint -install nebula`.

You can find Nebula's configuration options in your admin panel (admin > extensions > nebula). If you like the theme please leave a review on the marketplace where you've bought Nebula.


* Configuration
Configure Nebula in **Nebula Designer**! It's a custom-made admin section specifically for adjusting how Nebula looks and feels.


* Need help?
You can find my contact information on **prpl.wtf** or (in some cases) you can use the marketplace you've bought Nebula to send me a message.
